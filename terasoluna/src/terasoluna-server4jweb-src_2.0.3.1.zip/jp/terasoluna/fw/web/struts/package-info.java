/**
 * Web�ł�Struts�֘A
 */
package jp.terasoluna.fw.web.struts;